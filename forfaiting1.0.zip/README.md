# forfaiting

this is Forfaiting blockchain demo.
Although it is a simple application, this can demostrate how Forfaiting life sicle is.


